#!/bin/sh

nohup ./mindoc_linux_amd64 &